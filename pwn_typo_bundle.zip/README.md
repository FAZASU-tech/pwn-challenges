# pwn / The Typo

**Category:** pwn (binary exploitation)
**Difficulty:** Easy (great for a first stack-smashing challenge)
**Files:** `chall` (binary), `chall.c` (source — give this out for a "glass box" / teaching version; withhold it for a blind version)

## Challenge blurb

> Typo Corp's dev team "fixed" a buffer overflow bug last sprint by shrinking
> the buffer... but the code review missed something. Can you find the typo
> and get a shell?
>
> `nc <host> <port>`

## Setup

```bash
make              # builds ./chall
./chall           # run it locally
make release      # produces a stripped release/chall for distribution
```

To serve it over the network for players (e.g. with `socat` or `xinetd`):

```bash
socat TCP-LISTEN:1337,reuseaddr,fork EXEC:./chall
```

## The bug

```c
void vuln() {
    char buffer[32];      // buffer shrunk to 32 bytes...
    ...
    gets(buffer);          // ...but gets() has NO bound at all
}
```

`gets()` never checks how much it reads — it keeps reading until a newline,
however long the input is. That's the "typo": whoever "fixed" the size
forgot that `gets()` doesn't care about the buffer size in the first place.
This is a textbook unbounded stack buffer overflow (think CWE-121 /
CWE-242 — "Use of Inherently Dangerous Function").

There's also a `win()` function that's never called from `main()` — it just
sits in the binary waiting to be jumped to:

```c
void win() {
    system("/bin/sh");
}
```

## Exploitation path

1. The binary is compiled `-no-pie` with `-fno-stack-protector`, so:
   - No ASLR on the binary's own code (addresses are fixed).
   - No stack canary to detect the overflow before `ret`.
2. Disassembling `vuln()` shows `buffer` sits at `rbp-0x20` (32 bytes),
   followed by the saved `rbp` (8 bytes) and then the saved return address.
3. So: **40 bytes of padding** + **8 bytes for the address of `win()`**
   overwrites the return address, and when `vuln()` returns, execution
   jumps straight into `win()`.

Find `win()`'s address yourself:

```bash
objdump -d chall | grep '<win>:'
```

4. **Gotcha:** jumping straight to `win()` segfaults! `system()` uses SSE
   instructions internally that require the stack to be 16-byte aligned
   at the call, and a direct return-address overwrite leaves `rsp`
   misaligned by 8 bytes. Fix it by returning through one bare `ret`
   instruction first (find one with `objdump -d chall | grep 'c3 *$'`),
   which eats 8 bytes of stack and restores alignment before falling
   into `win()`. This is a great teaching moment on calling conventions.

## Solve

```bash
pip install pwntools
python3 solve.py            # local
python3 solve.py HOST PORT  # remote
```

`solve.py` sends `b"A"*40 + p64(ret_gadget) + p64(win_addr)` and drops
you into an interactive `/bin/sh`.

## Flag

Drop a `flag.txt` next to the binary and have `win()` `cat` it instead of
spawning a shell directly, e.g.:

```c
void win() {
    system("cat flag.txt; echo");
}
```

(A full interactive shell is more fun for teaching, but a direct `cat` is
more typical for an actual scored CTF so players can't poke around.)

## Variants / ways to make it harder

- Re-enable the stack canary (`-fstack-protector-all`) and require a
  canary leak via a format-string bug or partial overwrite first.
- Compile as PIE and require a leaked libc/binary base address.
- Remove `win()` entirely and require a full `ret2libc` chain instead.
- Strip the binary and withhold `chall.c` for a blind reversing step.

## Learning goals

- Reading disassembly to find a vulnerable function's stack layout.
- Understanding why `gets()` is banned in modern C (always use `fgets`
  with an explicit size).
- Overwriting a saved return address to redirect control flow.
- Why canaries, ASLR/PIE, and `NX`/`execstack` settings matter, and how
  each one would have blocked (or complicated) this exact exploit.
