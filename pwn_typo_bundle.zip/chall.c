// pwn_typo - "The Typo"
// A junior dev "fixed" a bug by shrinking a buffer but forgot to update
// the read size to match. Can you spot the typo and exploit it?
//
// Build (intentionally weak protections for a teaching challenge):
//   gcc -o chall chall.c -fno-stack-protector -no-pie -z execstack -g
//
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

void win() {
    printf("\n[+] Nice catch! Here's your shell:\n");
    fflush(stdout);
    system("/bin/sh");
}

void vuln() {
    char buffer[32];          // <-- buffer was shrunk from 64 to 32...
    printf("Patch notes say the buffer is only 32 bytes now.\n");
    printf("Enter your name: ");
    fflush(stdout);

    // ...but whoever "fixed" the size typo'd the read limit below.
    // It still reads up to 64 bytes into a 32-byte buffer.
    gets(buffer);              // deliberately vulnerable: no bounds check at all

    printf("Hello, %s!\n", buffer);
}

int main(void) {
    setvbuf(stdout, NULL, _IONBF, 0);
    setvbuf(stdin, NULL, _IONBF, 0);

    printf("=== Typo Corp Greeting Service v1.1 (patched!) ===\n");
    vuln();

    printf("Thanks for visiting. Goodbye.\n");
    return 0;
}
